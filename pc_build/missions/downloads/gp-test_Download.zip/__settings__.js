ASSET_PREFIX = "";
SCRIPT_PREFIX = "";
SCENE_PATH = "1483413.json";
CONTEXT_OPTIONS = {
    'antialias': true,
    'alpha': false,
    'preserveDrawingBuffer': false,
    'preferWebGl2': true,
    'powerPreference': "default"
};
SCRIPTS = [ 91963262, 91962490, 91963273, 91963275, 91963356, 92090476, 92215547, 92799578 ];
CONFIG_FILENAME = "config.json";
INPUT_SETTINGS = {
    useKeyboard: false,
    useMouse: true,
    useGamepads: false,
    useTouch: true
};
pc.script.legacy = false;
PRELOAD_MODULES = [
];
